<?php 
	header('location: ../');
 ?>